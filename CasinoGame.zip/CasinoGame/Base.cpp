//
// Created by Ushi on 5/26/2022.
//
#include <iostream>
#include<windows.h>

#include "mysql.h"

#include "Base.h"


#define GREEN   "\033[32m"      /* Green */
#define RED     "\033[31m" /* red */

#define HOST "localhost"
#define PORT 3306
#define USER "root"
#define PSW  "root"
#define DB   "casino"


//  ================    \\
\\  Connect database    //
MYSQL *Base::dbConnect()
{
    MYSQL *db;

    db = mysql_init(nullptr);
    db = mysql_real_connect(db, HOST, USER, PSW, DB, PORT, nullptr, 0);

    return db;
}


//  Set the warning
void Base::setWarning(std::string msg) {
    m_warning = std::move(msg);
}

//  ==============================  \\
\\  Define the position on console  //
std::string Base::setpos(std::string str, float x, float y)
{
    HANDLE hOut(GetStdHandle(STD_OUTPUT_HANDLE));

    //  If the position is not define, place on center
    if (x==0 && y==0) {
        CONSOLE_SCREEN_BUFFER_INFO csbi;

        if (GetConsoleScreenBufferInfo(hOut, &csbi))
        {
            int position = ((csbi.srWindow.Right - csbi.srWindow.Left) / 2) - ((int)str.size() / 2);

            for (int i=1; i<=position; ++i)
                std::cout<< " ";

            std::cout<< str;
        }
    }
    else {
        COORD place;
        place.X = x;
        place.Y = y;

        SetConsoleCursorPosition(hOut, place);

        std::cout<< str;
    }

    return "";
}


//  =============== \\
\\  Show the banner //
void Base::showBanner(std::string title) {
    system("cls");
    system("Color 02");

    std::string underlines;

    std::cout<<std::endl;
    std::cout<< setpos("CCCCC        A        SSSSSSSSS    IIIIIIIII    NN     NN     OOOOOOO") <<std::endl;
    std::cout<< setpos("CC            A A       SS              III       NN N   NN    OO     OO") <<std::endl;
    std::cout<< setpos("CC            A   A      SSSSSSSSS       III       NN  N  NN   OO       OO") <<std::endl;
    std::cout<< setpos("CC          AAAAAAA            SS       III       NN   N NN    OO     OO") <<std::endl;
    std::cout<< setpos("CCCCC    A       A    SSSSSSSSS    IIIIIIIII    NN     NN     OOOOOOO") <<std::endl;

    //  Show the title
    std::cout<<std::endl<<std::endl<< setpos(title) <<std::endl;

    //  Get the underline from title
    for (int i=1; i<=title.length(); i++)
        underlines += "=";

    //  Show the underline
    std::cout<< setpos(underlines) <<std::endl;

    //  Show the warning message
    if (!m_warning.empty()) {
        std::cout<<std::endl<< RED << setpos(m_warning) << GREEN <<std::endl<<std::endl;
        setWarning("");
    }
}

//  Get the date
std::string Base::getDate()
{
    time_t     now = time(0);
    struct tm  tStruct;
    char       buf[80];

    tStruct = *localtime(&now);

    strftime(buf, sizeof(buf), "%d-%m-%Y", &tStruct);

    return buf;
}

//  ============    \\
\\  quit the app    //
bool Base::logout()
{
    char option;

    while (true) {
        showBanner("Logout");

        std::cout<< setpos("1. Yes", 57, 14);
        std::cout<< setpos("2. No" , 57, 15);

        try {
            std::cout<< setpos("Choice: ", 56, 18);
            std::cin>>option;

            if (!isdigit(option) || (option - '0') < 1 || (option - '0') > 2)
                throw std::runtime_error("Please select the correct option (1 / 2)");
        }
        catch (std::exception &e)
        {
            setWarning(e.what());
            m_warning = "";
        }

        if (option == '1')
            return true;
        else if (option == '2')
            return false;
    }
}