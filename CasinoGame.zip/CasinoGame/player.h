//
// Created by Ushi on 5/26/2022.
//

#ifndef CSINOGAME_PLAYER_H
#define CSINOGAME_PLAYER_H

#include "Base.h"

class Player : public Base
{
    private:
        std::string m_username;
        int m_id, m_balance, m_profit, m_loss, m_plays;

        int secretNumber;
        int inputNumber;
        int betAmount;

        std::string m_result;

    public:
        void startSignin(std::string username="", std::string password="");
        void startSignup();
        void mainMenu();

        void showPlayerInfos();
        void showPlayerResult();
        void borrowMoney();
        void startPlaying();
};


#endif //CSINOGAME_PLAYER_H
