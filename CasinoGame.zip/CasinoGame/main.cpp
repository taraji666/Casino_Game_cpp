#include<iostream>

#include "player.h"

int main()
{
    auto *base = new Player;

    int start(0);
    char option;

    do {
        //  Show the banner
        base->showBanner("Welcome to our casino");

        std::cout<< base->setpos("1. Sign in", 55, 14);
        std::cout<< base->setpos("2. Sign up", 55, 15);
        std::cout<< base->setpos("3. Admin", 55, 17);
        std::cout<< base->setpos("4. Quit", 55, 18) <<std::endl;

        //  Check if the selected option is correct
        try {
            std::cout<< base->setpos("Option: ", 55, 21);
            std::cin >> option;

            if (!isdigit(option) || (option - '0') < 1 || (option - '0') > 4)
                throw std::runtime_error("Please select the correct option!!!");
        }
        catch (std::exception &e) {
            base->setWarning(e.what());
        }

        switch (option)
        {
            case '1':
                base->startSignin();
                break;

            case '2':
                base->startSignup();
                break;

            case '3':
                break;

            case '4':
                exit(0);
        }

        start++;
    }
    while (start>0);

    return 0;
}

