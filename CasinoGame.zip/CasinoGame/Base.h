//
// Created by Ushi on 5/26/2022.
//

#ifndef CSINOGAME_BASE_H
#define CSINOGAME_BASE_H

#include "mysql.h"

class Base
{
    private:
        std::string m_warning;

    public:
        std::string getDate();
        MYSQL *dbConnect();

        void showBanner(std::string str);
        std::string setpos(std::string str, float x=0, float y=0);

        void setWarning(std::string msg);

        bool logout();
};


#endif //CSINOGAME_BASE_H
