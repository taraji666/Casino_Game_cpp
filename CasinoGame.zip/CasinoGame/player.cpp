//
// Created by Ushi on 5/26/2022.
//
#include <iostream>
#include <conio.h>

#include "player.h"


#define RESET   "\033[0m"
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */


//  ==============   \\
\\  sign in system   //
void Player::startSignin(std::string username, std::string password)
{
    MYSQL     *db(dbConnect());
    MYSQL_RES *res;
    MYSQL_ROW row;

    bool emptyVars; // true if (username and password) variable come empty.

    do {
        if (username.empty() && password.empty())
        {
            showBanner("Sign In");
            emptyVars = true;

            char psw;

            std::cout<< setpos("Enter your username : ", 39, 14);
            std::getline(std::cin>>std::ws, username);

            std::cout<< setpos("Enter your password : ", 39, 16);
            psw = _getch();

            //  show password as *
            while (psw != 13) {
                password.push_back(psw);

                std::cout<< '*';
                psw = _getch();
            }
        }

        //  Get user's information
        std::string request("SELECT * FROM players WHERE username='"+username+"' AND password='"+password+"' ");
        int status = mysql_query(db, request.c_str());

        if (status == 0)
        {
            res = mysql_store_result(db);

            if (mysql_num_rows(res) > 0) {
                row = mysql_fetch_row(res);

                m_username = row[1];
                m_id       = atoi(row[0]);
                m_balance  = atoi(row[3]);
                m_profit   = atoi(row[4]);
                m_loss     = atoi(row[5]);
                m_plays    = atoi(row[6]);

                mainMenu();
                mysql_close(db);
                break;
            }
            else
            {
                setWarning("Error: user ("+ username +") not found");

                if (emptyVars) {
                    username="";
                    password="";
                }
            }
        }
        else {
            std::string err("Error: Database -> ");
            setWarning(err + mysql_error(db));
        }
    }
    while (true);
}


//  ======================= \\
\\  Start signing up system //
void Player::startSignup()
{
    MYSQL *db(dbConnect());

    std::string username, password, confirm;
    char psw, conf;

    do {
        showBanner("Sign Up");

        std::cout<< setpos("Enter the username   : ", 40, 14);
        std::getline(std::cin>>std::ws, username);

        std::cout<< setpos("Enter the password   : ", 40, 16);
        psw = _getch();

        //  show password as *
        while (psw != 13) {
            password.push_back(psw);

            std::cout<< '*';
            psw = _getch();
        }

        std::cout<< setpos("Confirm the password : ", 40, 18);
        conf = _getch();

        //  show password as *
        while (conf != 13) {
            confirm.push_back(conf);

            std::cout<< '*';
            conf = _getch();
        }

        //  Check if the password is correct
        if (password == confirm)
        {
            //  Save new player in database
            std::string request("INSERT INTO players (username, password, created) VALUES('"+username+"', '"+password+"', '"+getDate()+"')");
            int status = mysql_query(db, request.c_str());

            if (status == 0)
            {
                setWarning("MSG: Thank you for joining our casino.");
                startSignin(username, password);
                mysql_close(db);
                break;
            }
            else {
                std::string err("Error: Database -> ");
                setWarning(err + mysql_error(db));
            }
        }
        else
            setWarning("Error: Your password must match with the confirmation!!!");
    }
    while (true);
}


//  =========   \\
\\  Main menu   //
void Player::mainMenu()
{
    char option;

    do {
        showBanner("MAIN MENU");

        //  Show player information
        showPlayerInfos();

        //  Show player result after playing
        showPlayerResult();

        std::cout<< setpos("1. Play", 55, 14);

        if (m_balance<=100) {
            std::cout<< setpos("2. Borrow", 55, 16);
            std::cout<< setpos("3. Logout", 55, 17);
        }
        else
            std::cout<< setpos("2. Logout", 55, 16);


        try {
            std::cout<< setpos("Option: ", 55, 20);
            std::cin>>option;

            //  Check if player entered a digit
            if (!isdigit(option))
                throw std::runtime_error("Error: Please select the correct option!!!");
        }
        catch (std::exception &e) {
            setWarning(e.what());
        }

        if (option == '1')
            startPlaying();
        else if (m_balance<=100)
        {
            if (option == '2')
                borrowMoney();
            else if (option=='3') {
                if (logout())
                    break;
            }
            else
                setWarning("Error: Please select the correct option!!!");
        }
        else if (option == '2') {
            if (logout())
                break;
        }
        else
            setWarning("Error: Please select the correct option!!!");
    }
    while (true);
}


//  =======================   \\
\\  Show player information   //
void Player::showPlayerInfos()
{
    for (int i=16; i<=26; ++i)
        setpos("|*", 3, i);
        std::cout<<std::endl;


    std::cout<< setpos("Username : "+ m_username, 6, 17);
    std::cout<< setpos("Balance  : ", 6, 19);
    std::cout<< setpos("Profit   : $"+ std::to_string(m_profit), 6, 21);
    std::cout<< setpos("Loss     : $"+ std::to_string(m_loss), 6, 23);
    std::cout<< setpos("Played   : "+ std::to_string(m_plays) +" times", 6, 25);

    //  if balance <= 100 put it on red else if it's <= 260 make it yellow
    std::cout
        << ((m_balance<=100) ? RED : (m_balance<=260) ? YELLOW : GREEN)
        << setpos("$"+ std::to_string(m_balance), 17, 19)
        << GREEN
    ;
}


//  ============    \\
\\  Borrow money    //
void Player::borrowMoney()
{
    MYSQL *db(dbConnect());
    std::string amount;

    do {
        showBanner("Borrow Money");

        //  Show player information
        showPlayerInfos();

        //  Show the notice
        std::cout
            << YELLOW
            << setpos("The max amount to borrow is $600", 43, 22)
            << setpos("Enter q to cancel", 50, 24)
            << GREEN
        ;

        //  Get the amount to borrow
        setpos("Enter the amount: ", 50, 14);
        std::cin>>amount;

        //  If it's q, then cancel
        if (amount == "q")
            break;

        if (std::stoi(amount) >= 1 && std::stoi(amount) <= 600)
        {
            m_balance += std::stoi(amount);

            std::string request("UPDATE players SET balance="+std::to_string(m_balance)+" WHERE id= "+ std::to_string(m_id));
            if (mysql_query(db, request.c_str()) == 0) {
                setWarning("you have just had a loan of $"+ amount +".");
                mysql_close(db);
                break;
            }
            else {
                std::string err("Error: Database -> ");
                setWarning(err + mysql_error(db));
            }
        }
        else
            setWarning("Please enter a correct amount between 1-600$");
    }
    while (true);
}


//  ======================  \\
\\  Start playing the game  //
void Player::startPlaying()
{
    MYSQL *db(dbConnect());

    std::string table; //   Table to update (profit/loss)
    int amount;        //   Amount to update

    do{
        //  Generate the secret number
        {
            srand(time(0));
            secretNumber = rand() % 10;
        }

        showBanner("Borrow Money");

        //  Show player information
        showPlayerInfos();

        //  Get the amount to borrow
        setpos("Enter the amount to bet : ", 46, 14);
        std::cin>>betAmount;

        //  Check if the bet amount is correct
        if (betAmount <= m_balance && betAmount > 0)
        {
            //  Show the notice
            std::cout
                << YELLOW
                << setpos("- You have to choose the number between 0 and 10", 38, 20)
                << setpos("- If the number match with the secret number, you won", 38, 22)
                << setpos("- Else if the number is in the same class (even/odd)", 38, 24)
                << setpos("you'll get your money plus the half of it.", 40, 25)
                << setpos("- Otherwise, you lose the game", 38, 27)
                << GREEN
            ;

            //  Get the input number from player
            setpos("Enter your number       : ", 46, 16);
            std::cin>>inputNumber;

            //  Check is the number respect the rules
            if (inputNumber >= 0 && inputNumber <= 10)
            {
                m_plays += 1;

                //  Play verifications
                if (inputNumber == secretNumber) {  //  Won
                    table      = "profit";
                    amount     = betAmount;

                    m_profit  += betAmount;
                    m_balance += betAmount;
                    m_result   = "Won $"+ std::to_string(betAmount);
                }
                else if ( //  draw (even/odd)
                    (inputNumber%2 == 0 && secretNumber%2 == 0) ||
                    (inputNumber%2 != 0 && secretNumber%2 != 0)
                ) {
                    table      = "profit";
                    amount     = (betAmount / 2);

                    m_profit  += (betAmount / 2);
                    m_balance += (betAmount / 2);
                    m_result   = "Draw $"+ std::to_string(betAmount/2);
                }
                else if (inputNumber != secretNumber) {  //  Lose
                    table      = "loss";
                    amount     = betAmount;

                    m_loss    += betAmount;
                    m_balance -= betAmount;
                    m_result   = "Lose $"+ std::to_string(betAmount);
                }

                //  Update information in database
                std::string request("UPDATE players SET balance="+std::to_string(m_balance)+", "+table+"= "+table+" + "+std::to_string(amount)+", plays = plays+1 WHERE id="+ std::to_string(m_id));
                if (mysql_query(db, request.c_str()) == 0) {
                    mysql_close(db);
                    break;
                }
                else {
                    std::string err("Error: Database -> ");
                    setWarning(err + mysql_error(db));
                }
            }
            else
                setWarning("Please select a correct number (0 - 10)");
        }
        else {
            setWarning("Please bet a correct amount between $1 and $"+ std::to_string(m_balance));
            break;
        }
    }
    while (true);
}

//  Show user's results after playing
void Player::showPlayerResult() {
    if (!m_result.empty())
    {
        std::cout<< RESET;
        std::cout<< setpos("Secret number: "+ std::to_string(secretNumber), 90, 20);
        std::cout<< setpos("Played number: "+ std::to_string(inputNumber) , 90, 21);
        std::cout<< setpos("Bet amount   : $"+ std::to_string(betAmount)  , 90, 22);
        std::cout<< setpos("Result       : "+ m_result, 90, 23);
        std::cout<< GREEN;

        m_result = "";
    }
}